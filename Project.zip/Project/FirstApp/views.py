from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request,'FirstApp/index.html')
def help(request):
    my_dict = {'helper':'Helper@gmail.com'}
    return render(request,'FirstApp/help.html',context=my_dict)