from django.urls import path
from FirstApp import views
from django.conf.urls import url
urlpatterns = [
    url(r'help/$',views.help),
    url(r'^$',views.index),
]